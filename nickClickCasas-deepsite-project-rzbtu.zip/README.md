---
title: DeepSite Project
colorFrom: blue
colorTo: red
sdk: static
emoji: 💎
tags:
  - deepsite-v4
---

# DeepSite Project

This project has been created with [DeepSite](https://deepsite.hf.co) AI Vibe Coding.
